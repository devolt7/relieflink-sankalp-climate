# ReliefLink – Person 1: Camp Portal + Verification (F2, F7-camp, F3-camp side)

Run: open `relieflink-camp-portal.html` in a browser (no install). Data lives in browser localStorage (key `relieflink_camp_v2`). Demo data is labelled "DEMO".

## 1. Structure
One file. `DATA LAYER` block (const `api`, `seed()`, `db`) is the ONLY code touching storage – replace it with backend calls. `UI` block = views `vDash vForm vNeed vCamp vAdmin`, router `route()`, event handlers. `LANGUAGE + THEME` block = Hindi/English dictionary `HI` and dark/light toggle.
Routes: `#/` dashboard · `#/new` · `#/edit/:id` · `#/camp/:id` · `#/editneed/:id` · `#/admin`.
Relationship: Camp 1─* Need 1─* Pledge. Full SQL in `schema.sql`.

## 2. Camp
`id, name, district, state, contactNumber, nearestBranch, capacity, occupancy, status, decidedAt, rejectionReason`
- status: `Pending | Verified | Rejected`. New camp is ALWAYS Pending. Only Pending → Verified/Rejected; rejection needs a reason.
- `nearestBranch` is a branch NAME now → use `branchId` (FK to branches) in the shared DB.
- `occupancy` ≤ `capacity`. `decidedAt` = when branch approved/rejected.

## 3. Need
`id, campId, item, quantity, priority, fulfilledQuantity` — priority `Low | Medium | High`.
remaining = quantity − fulfilledQuantity. Only Verified camps can post needs. Critical (UI only) = High priority and fulfilled < 50%.

## 4. Pledge  (Person 2 creates these)
`id, needId, donorName, donorContact, quantity, note, status, createdAt, dispatchedAt, receivedAt, receivedQuantity, disputed, disputeNote`
- status `Pledged | Dispatched | Received`.
- **Rule:** creating a pledge NEVER changes `fulfilledQuantity`. Only camp's "Mark Received" (Dispatched → Received) adds `receivedQuantity` (≤ pledge quantity, capped at remaining need). Partial receive is allowed.
- `disputed=true` is set by the camp ("Not received"); donor portal may show it.

## 5. API surface (`api` object) → suggested REST
| api method | REST |
|---|---|
| camps(), camp(id), createCamp(d) | GET /camps, GET /camps/:id, POST /camps (forces Pending) |
| updateCamp(id,d) / deleteCamp(id) | PATCH /camps/:id / DELETE /camps/:id (cascade needs+pledges) |
| setStatus(id,s,reason) | POST /camps/:id/status {status, reason} (admin only, Pending only) |
| needsOf, addNeed, updateNeed, deleteNeed | GET/POST /camps/:id/needs, PATCH/DELETE /needs/:id |
| pledgesOf, addPledge | GET/POST /needs/:id/pledges  (addPledge = Person 2) |
| dispatch(id) | POST /pledges/:id/dispatch  (Person 2) |
| dispute(id,note) | POST /pledges/:id/dispute |
| receive(id,qty) | POST /pledges/:id/receive {quantity} – do pledge update + need.fulfilledQuantity in ONE transaction |

## 6. Connect to a shared backend
1. Make each `api` method `async` (fetch/Supabase/Firebase) and `await` them in views/handlers.
2. Delete `seed()`, localStorage code and buttons labelled "Demo:" (they simulate the Donor Portal).
3. Enforce status rules and the pledge≠fulfilled rule on the server too.
4. Replace `BRANCHES` with a `branches` table; store `branchId`.
5. Add real auth: `/admin` (Verification) must be branch/admin only.
6. Design tokens are CSS variables in `:root` – Person 4 can swap them.

## 7. Left for others
- Person 2: Donor Portal – create pledges, set Dispatched, "Verified only" filter / warn on unverified camps, My Pledges, notifications (F9). Read `fulfilledQuantity` for progress.
- Person 3: Satin branch dashboard (camps by `nearestBranch`), flood risk, Impact stats. For avg fulfilment time use pledge `createdAt`→`receivedAt`.
- Person 4: landing page, shared design, realistic seed data (replace DEMO data), typo pass.

## 8. Known limits
No auth; Hindi covers UI text only (user data not translated); CSV export = file download; branch list is demo.
