-- Suggested shared schema (Postgres). Adjust names to the team's final DB.
create table branches (id text primary key, name text not null, district text, state text);
create table camps (
  id text primary key, name text not null, district text not null, state text not null,
  contact_number text not null, branch_id text not null references branches(id),
  capacity int not null check (capacity >= 0), occupancy int not null default 0 check (occupancy >= 0),
  status text not null default 'Pending' check (status in ('Pending','Verified','Rejected')),
  decided_at timestamptz, rejection_reason text, created_at timestamptz default now());
create table needs (
  id text primary key, camp_id text not null references camps(id) on delete cascade,
  item text not null, quantity int not null check (quantity > 0),
  priority text not null check (priority in ('Low','Medium','High')),
  fulfilled_quantity int not null default 0 check (fulfilled_quantity >= 0 and fulfilled_quantity <= quantity));
create table pledges (
  id text primary key, need_id text not null references needs(id) on delete cascade,
  donor_name text not null, donor_contact text not null, quantity int not null check (quantity > 0), note text,
  status text not null default 'Pledged' check (status in ('Pledged','Dispatched','Received')),
  created_at timestamptz default now(), dispatched_at timestamptz, received_at timestamptz,
  received_quantity int default 0, disputed boolean default false, dispute_note text);
